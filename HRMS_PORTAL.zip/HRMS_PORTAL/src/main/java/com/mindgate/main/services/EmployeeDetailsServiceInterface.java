package com.mindgate.main.services;

import com.mindgate.main.domain.EmployeeDetails;

public interface EmployeeDetailsServiceInterface {

	

	public  EmployeeDetails getByLoginId(int loginId);
}
